///*
// * File:   Motor_speed.c
// * Author: Abdul Qadeer
// *
// * Created on August 23, 2020, 3:47 PM
// */
//
//
//// PIC18F4550 Configuration Bit Settings
//
//// 'C' source line config statements
//
//// CONFIG1L
//#pragma config PLLDIV = 1       // PLL Prescaler Selection bits (No prescale (4 MHz oscillator input drives PLL directly))
//#pragma config CPUDIV = OSC1_PLL2// System Clock Postscaler Selection bits ([Primary Oscillator Src: /1][96 MHz PLL Src: /2])
//#pragma config USBDIV = 1       // USB Clock Selection bit (used in Full-Speed USB mode only; UCFG:FSEN = 1) (USB clock source comes directly from the primary oscillator block with no postscale)
//
//// CONFIG1H
//#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator (HS))
//#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enable bit (Fail-Safe Clock Monitor disabled)
//#pragma config IESO = OFF       // Internal/External Oscillator Switchover bit (Oscillator Switchover mode disabled)
//
//// CONFIG2L
//#pragma config PWRT = OFF       // Power-up Timer Enable bit (PWRT disabled)
//#pragma config BOR = OFF        // Brown-out Reset Enable bits (Brown-out Reset disabled in hardware and software)
//#pragma config BORV = 3         // Brown-out Reset Voltage bits (Minimum setting 2.05V)
//#pragma config VREGEN = OFF     // USB Voltage Regulator Enable bit (USB voltage regulator disabled)
//
//// CONFIG2H
//#pragma config WDT = OFF        // Watchdog Timer Enable bit (WDT disabled (control is placed on the SWDTEN bit))
//#pragma config WDTPS = 32768    // Watchdog Timer Postscale Select bits (1:32768)
//
//// CONFIG3H
//#pragma config CCP2MX = ON      // CCP2 MUX bit (CCP2 input/output is multiplexed with RC1)
//#pragma config PBADEN = ON      // PORTB A/D Enable bit (PORTB<4:0> pins are configured as analog input channels on Reset)
//#pragma config LPT1OSC = OFF    // Low-Power Timer 1 Oscillator Enable bit (Timer1 configured for higher power operation)
//#pragma config MCLRE = ON       // MCLR Pin Enable bit (MCLR pin enabled; RE3 input pin disabled)
//
//// CONFIG4L
//#pragma config STVREN = ON      // Stack Full/Underflow Reset Enable bit (Stack full/underflow will cause Reset)
//#pragma config LVP = ON         // Single-Supply ICSP Enable bit (Single-Supply ICSP enabled)
//#pragma config ICPRT = OFF      // Dedicated In-Circuit Debug/Programming Port (ICPORT) Enable bit (ICPORT disabled)
//#pragma config XINST = OFF      // Extended Instruction Set Enable bit (Instruction set extension and Indexed Addressing mode disabled (Legacy mode))
//
//// CONFIG5L
//#pragma config CP0 = OFF        // Code Protection bit (Block 0 (000800-001FFFh) is not code-protected)
//#pragma config CP1 = OFF        // Code Protection bit (Block 1 (002000-003FFFh) is not code-protected)
//#pragma config CP2 = OFF        // Code Protection bit (Block 2 (004000-005FFFh) is not code-protected)
//#pragma config CP3 = OFF        // Code Protection bit (Block 3 (006000-007FFFh) is not code-protected)
//
//// CONFIG5H
//#pragma config CPB = OFF        // Boot Block Code Protection bit (Boot block (000000-0007FFh) is not code-protected)
//#pragma config CPD = OFF        // Data EEPROM Code Protection bit (Data EEPROM is not code-protected)
//
//// CONFIG6L
//#pragma config WRT0 = OFF       // Write Protection bit (Block 0 (000800-001FFFh) is not write-protected)
//#pragma config WRT1 = OFF       // Write Protection bit (Block 1 (002000-003FFFh) is not write-protected)
//#pragma config WRT2 = OFF       // Write Protection bit (Block 2 (004000-005FFFh) is not write-protected)
//#pragma config WRT3 = OFF       // Write Protection bit (Block 3 (006000-007FFFh) is not write-protected)
//
//// CONFIG6H
//#pragma config WRTC = OFF       // Configuration Register Write Protection bit (Configuration registers (300000-3000FFh) are not write-protected)
//#pragma config WRTB = OFF       // Boot Block Write Protection bit (Boot block (000000-0007FFh) is not write-protected)
//#pragma config WRTD = OFF       // Data EEPROM Write Protection bit (Data EEPROM is not write-protected)
//
//// CONFIG7L
//#pragma config EBTR0 = OFF      // Table Read Protection bit (Block 0 (000800-001FFFh) is not protected from table reads executed in other blocks)
//#pragma config EBTR1 = OFF      // Table Read Protection bit (Block 1 (002000-003FFFh) is not protected from table reads executed in other blocks)
//#pragma config EBTR2 = OFF      // Table Read Protection bit (Block 2 (004000-005FFFh) is not protected from table reads executed in other blocks)
//#pragma config EBTR3 = OFF      // Table Read Protection bit (Block 3 (006000-007FFFh) is not protected from table reads executed in other blocks)
//
//// CONFIG7H
//#pragma config EBTRB = OFF      // Boot Block Table Read Protection bit (Boot block (000000-0007FFh) is not protected from table reads executed in other blocks)
//
//// #pragma config statements should precede project file includes.
//// Use project enums instead of #define for ON and OFF.
//
//#include <xc.h>
//int keypad_ten();
//int keypad_unit();
//void motor(int number_pwm);
//void delay(int ms);
////#define row1 PORTBbits.RB0;
////#define row2 PORTBbits.RB1;
////#define row3 PORTBbits.RB2;
////#define row4 PORTBbits.RB3;
////#define col1 PORTBbits.RB4;
////#define col2 PORTBbits.RB5;
////#define col3 PORTBbits.RB6;
//int digit=0;
//int speed[2];
//int ten=0;
//int unit=0;
//int tenth=0;
//int number=0;
//int key_stroke=0;
//int check=0;
//
//void main(void){
//    TRISA=0x0F;   //for keyboard
//    TRISD=0x00;
//    PORTD=0x00;
//    TRISC=0x00;         // for motor 
////    TRISA=0x07;
////    ECCP1CON = 0B01001100; //what the hell it is creating
////    T2CON = 0B00000000;
////    int count=0;
////    TMR2ON=1;
////    PR2 = 255;
////    CCPR1L = 190;
//    while(1){
//        PORTC=keypad_unit();
//        PORTD=keypad_unit();
//        delay(100);
//    }
//}
//
//int keypad_unit(){
////    Column 1 checking
//    PORTAbits.RA4 =1;PORTAbits.RA5 =0;PORTAbits.RA6 =0;
////    col1 = 1; col2 = 0;col3 = 0;
//    if (PORTAbits.RA0 && PORTAbits.RA4 ){
//        delay(1);
//        return 1;
//    }
//    else if(PORTAbits.RA1 && PORTAbits.RA4 ){
//        delay(1);
//        return 4;
//    }
//    else if(PORTAbits.RA2 && PORTAbits.RA4 ){
//        delay(1);
//        return 7;
//    }
//    else if(PORTAbits.RA3 && PORTAbits.RA4 ){
//        delay(1);
//        return 0;
//    }
////    Column 2 checking
//    PORTAbits.RA4 =0;PORTAbits.RA5 =1;PORTAbits.RA6 =0;
////    col1 = 0; col2 = 1;col3 = 0;
//    if(PORTAbits.RA0 && PORTAbits.RA5 ){
//        delay(1);
//        return 2;
//    }
//    else if(PORTAbits.RA1 && PORTAbits.RA5 ){
//        delay(1);
//        return 5;
//    }
//    else if(PORTAbits.RA2 && PORTAbits.RA5 ){
//        delay(1);
//        return 8;
//    }
//    else if(PORTAbits.RA3 && PORTAbits.RA5 ){
//        delay(1);
//        return 0;
//    }
////    Column 3 checking
//    PORTAbits.RA4 =0;PORTAbits.RA5 =0;PORTAbits.RA6 =1;
////    col1 = 0; col2 = 0;col3 = 1;
//    if(PORTAbits.RA0 && PORTAbits.RA6 ){
//        delay(1);
//        return 3;
//    }
//    else if(PORTAbits.RA1 && PORTAbits.RA6 ){
//        delay(1);
//        return 6;
//    }
//    else if(PORTAbits.RA2 && PORTAbits.RA6){
//        delay(1);
//        return 9;
//    }
//    else if(PORTAbits.RA3 && PORTAbits.RA6 ){
//        delay(1);
//        return 0;
//    }
//}
////int keypad_ten(){
//////    Column 1 checking
////    PORTDbits.RD4 =1;PORTDbits.RD5 =0;PORTDbits.RD6 =0;
////    if (PORTDbits.RD0 && PORTDbits.RD4 ){
////        delay(1);
////        return 10;
////    }
////    else if(PORTDbits.RD1 && PORTDbits.RD4 ){
////        delay(1);
////        return 40;
////    }
////    else if(PORTDbits.RD2 && PORTDbits.RD4 ){
////        delay(1);
////        return 70;
////    }
////    else if(PORTDbits.RD3 && PORTDbits.RD4 ){
////        delay(1);
////        return 00;
////    }
//////    Column 2 checking
////    PORTDbits.RD4 =0;PORTDbits.RD5 =1;PORTDbits.RD6 =0;
////    if(PORTDbits.RD0 && PORTDbits.RD5 ){
////        delay(1);
////        return 20;
////    }
////    else if(PORTDbits.RD1 && PORTDbits.RD5 ){
////        delay(1);
////        return 50;
////    }
////    else if(PORTDbits.RD2 && PORTDbits.RD5 ){
////        delay(1);
////        return 80;
////    }
////    else if(PORTDbits.RD3 && PORTDbits.RD5 ){
////        delay(1);
////        return 00;
////    }
//////    Column 3 checking
////    PORTDbits.RD4 =0;PORTDbits.RD5 =0;PORTDbits.RD6 =1;
////    if(PORTDbits.RD0 && PORTDbits.RD6 ){
////        delay(1);
////        return 30;
////    }
////    else if(PORTDbits.RD1 && PORTDbits.RD6 ){
////        delay(1);
////        return 60;
////    }
////    else if(PORTDbits.RD2 && PORTDbits.RD6){
////        delay(1);
////        return 90;
////    }
////    else if(PORTDbits.RD3 && PORTDbits.RD6 ){
////        delay(1);
////        return 0;
////    }
////}
//
//void delay(int ms){
//    int i,j;
//    for(i=0; i<ms; i++)
//        for(j=0; j<75; j++);
//}
//void motor(int number_pwm){
//    if(number_pwm==0){
//        P1M1=0;
//        CCPR1L = ((250-number_pwm)*2*2);
//    }
//    else if(number_pwm==50){
//        CCPR1L=0;
//    }
//    else if(number_pwm>50){
//        P1M1 = 1;
//        CCPR1L = (number_pwm*2*2)-4;
//    }
//}