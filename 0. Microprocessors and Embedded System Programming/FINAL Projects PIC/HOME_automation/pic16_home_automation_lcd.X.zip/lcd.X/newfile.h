/* 
 * File:   newfile.h
 * Author: Pakistan zindabad
 *
 * Created on August 17, 2020, 2:07 PM
 */

#ifndef NEWFILE_H
#define	NEWFILE_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* NEWFILE_H */

